﻿namespace Example
{
    public interface IAnimal
    {
        string Talk();
		string ToMe();
    }
}